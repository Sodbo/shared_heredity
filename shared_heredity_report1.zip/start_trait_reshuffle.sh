Rscript 05_shared_heredity.R input/pheno_corr_matrix.txt input/gene_cov_matrix.txt >output/alphas.txt
Rscript 05_shared_heredity.R input/pheno_corr_matrix_reshuffled.txt input/gene_cov_matrix_reshuffled.txt >output/alphas_resuffled.txt

